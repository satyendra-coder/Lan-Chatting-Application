# LanChatApp
A Lan chat app built in Java by the use of network programming. Uses UDP (User Datagram Protocol) to send a message to all the clients through multicasting. The desktop application can be used  in a Local area network  to 
connect and text other users. Multiple users can text at the same time.
The project is built using Netbeans IDE. To use this project, just clone the repository and open the project using netbeans IDE.
# App in working

![alt text](https://github.com/PushpinderSinghGrewal/LanChatApp/blob/master/lanchatapp.jpeg)

 In the **Chat Window** box type the message you want to write and click on **Send**. The message will be sent to all the users who are online and are in the same Local Area Network.

